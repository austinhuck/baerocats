#!/bin/bash
doxygen Doxyfile
